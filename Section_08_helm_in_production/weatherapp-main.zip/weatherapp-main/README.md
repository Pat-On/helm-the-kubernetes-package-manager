This is a new feature
This feature #4
This should be version 2.5.0
This should be version 2.6.0
This will fail
Event bridge is not needed
